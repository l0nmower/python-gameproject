This is a small Python project in the form of a "Choose your own adventure" style game.
The name Gun Souls is just a nod to one of my favourite games, the Dark Souls series, but 
there are guns in this game, which don't exist in Dark Souls. Anyways, not meant to be 
taken too seriously, just a name because it needs a name. 

It is intended for myself as some kind of practical application of Python 
concepts, and to build my own comfort with the concepts as I continue on 
my programming journey.

