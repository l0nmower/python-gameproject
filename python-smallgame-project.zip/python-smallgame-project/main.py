print('''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
|                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/_____ /
*******************************************************************************
''')
print("Welcome to Guns Souls.")
print("Your mission is to not die.") 

game_start = print("\nYou are at a crossroads.\n\nTo the left is the district of Varstagrad. You will have to endure a long and cold swim across an unforgiving river. Little is known about Varstagrad's inhabitants, but you know that they have resources.\n\nThe path to your right can bring you to the city of Nekto in half the travel time if you make it through the Forest of the Wicked, known to be home to many dangerous animals and dark spirits.\n")

choice1 = input("Will you choose to go 'Left' or 'Right'?\n")

if choice1.lower() == "left":
 print("\nYou continue on your journey and reach Varstagrad after swimming for a few more hours. You ask around for information about the Silver Order and discover that there is a meeting at the local city hall. A stranger claiming to be your contact in the city tasks you to assassinate one of the leaders during this meeting, but it's risky. You can either accept the contract or decline it to continue exploring the city for further clues.  Or if you're feeling crazy, you can just kill this guy right here.\n")
 choice2 = input("'Accept' or 'Decline' or 'Kill'?\n")
 if choice2.lower() == "accept":
  print("It was a trap. The contact was a plant from the enemy faction. You are immediately surrounded by Lv. 100 Officers and they killed you in seconds.\n\nGame Over.")
 elif choice2.lower() == "kill":
  print("\nLeftYou are suspicious of the meeting, but you acted too erratically. It turns out the contact was a plant for the other side, but you were also being watched. You were killed shortly after killing the stranger.\n\nGame Over.")
 else:
  print("\nYou are suspicious of the meeting and decline the contract. You eventually find the headquarters of your faction and upgrade your materials. You are given a map of the city and a list of official targets to assassinate. The first one on your list is a corrupt politician who has been profiting at the expense of the working-class citizens of the city. You are given a choice in approach, quiet or loud.  You will be provided with one of two available weapons: Sniper Rifle or AK-47.\n\nIf the sniper rifle is chosen, you will be able to set up on the highest floor of the building adjacent to his office.\n\nIf you choose the AK-47, you will need to go in guns blazing and cause a massacre if you even manage to survive.\n\n")

  choice3 = input("'Loud' or 'Quiet'?\n")

  if choice3.lower() == "quiet":
   print("\nYou successfully eliminated the target.  You have been paid handsomely for your service and gained reputation within the city.\n\nYou win!")
  else:
   print("\nReally? You didn't think that would actually work, right?\n\nGame Over.")

else:
 print("\nYou were killed by a patrolling tiger.\n\nGame Over.")







